import TelegramBot from 'node-telegram-bot-api';
import { storage } from './storage';
import axios from 'axios';

const BOT_TOKEN = process.env.BOT_TOKEN || process.env.TELEGRAM_BOT_TOKEN || '';
const ADMIN_ID = '7011309417'; // Admin user ID
const API_BASE_URL = 'https://customize-turn-expand-bizarre.trycloudflare.com';

if (!BOT_TOKEN) {
  throw new Error('BOT_TOKEN environment variable is required');
}

class TelegramBotService {
  private bot: TelegramBot;
  private userSessions: Map<string, any> = new Map();
  private activePolls: Map<string, NodeJS.Timeout> = new Map();

  constructor() {
    this.bot = new TelegramBot(BOT_TOKEN, { polling: true });
    this.setupHandlers();
    this.initializeSettings();
  }

  private async initializeSettings() {
    // Initialize default settings if not exists
    try {
      const settings = await storage.getBotSettings();
      if (!settings) {
        await storage.updateBotSettings({
          maintenanceMode: false,
          maintenanceMessage: 'البوت تحت الصيانة، حاول لاحقاً',
          numberPrice: '0.50',
          minimumBalance: '1.00',
          dailyLimit: 10,
          referralCommission: 10,
          apiUrl: API_BASE_URL,
          welcomeMessage: 'مرحباً بك في بوت الأرقام! 🤖\n\nاختر الخدمة المطلوبة:',
          supportedServices: ['whatsapp', 'telegram', 'facebook', 'instagram', 'twitter'],
          supportedCountries: [
            {code: "EG", name: "مصر", flag: "🇪🇬"},
            {code: "SA", name: "السعودية", flag: "🇸🇦"},
            {code: "AE", name: "الإمارات", flag: "🇦🇪"},
            {code: "US", name: "أمريكا", flag: "🇺🇸"},
            {code: "GB", name: "بريطانيا", flag: "🇬🇧"},
            {code: "DE", name: "ألمانيا", flag: "🇩🇪"}
          ]
        });
      }
    } catch (error) {
      console.error('Error initializing settings:', error);
    }
  }

  private setupHandlers() {
    // Start command
    this.bot.onText(/\/start/, async (msg) => {
      await this.handleStart(msg);
    });

    // Admin commands
    this.bot.onText(/\/admin/, async (msg) => {
      await this.handleAdminCommand(msg);
    });

    this.bot.onText(/\/balance (.+)/, async (msg, match) => {
      await this.handleBalanceCommand(msg, match);
    });

    this.bot.onText(/\/broadcast (.+)/, async (msg, match) => {
      await this.handleBroadcastCommand(msg, match);
    });

    this.bot.onText(/\/direct (\d+) (.+)/, async (msg, match) => {
      await this.handleDirectCommand(msg, match);
    });

    this.bot.onText(/\/stats/, async (msg) => {
      await this.handleStatsCommand(msg);
    });

    this.bot.onText(/\/users/, async (msg) => {
      await this.handleUsersCommand(msg);
    });

    this.bot.onText(/\/settings/, async (msg) => {
      await this.handleSettingsCommand(msg);
    });

    this.bot.onText(/\/maintenance/, async (msg) => {
      await this.handleMaintenanceCommand(msg);
    });

    this.bot.onText(/\/channels/, async (msg) => {
      await this.handleChannelsCommand(msg);
    });

    this.bot.onText(/\/help/, async (msg) => {
      await this.handleHelpCommand(msg);
    });

    // Add number command for admin
    this.bot.onText(/\/addnumber (.+)/, async (msg, match) => {
      await this.handleAddNumberCommand(msg, match);
    });

    // User commands
    this.bot.onText(/\/mybalance/, async (msg) => {
      await this.handleMyBalanceCommand(msg);
    });

    this.bot.onText(/\/profile/, async (msg) => {
      await this.handleProfileCommand(msg);
    });

    // Handle callback queries (inline keyboard buttons)
    this.bot.on('callback_query', async (query) => {
      await this.handleCallbackQuery(query);
    });

    // Handle errors
    this.bot.on('error', (error) => {
      console.error('Telegram bot error:', error);
    });

    // Handle polling errors
    this.bot.on('polling_error', (error) => {
      console.error('Telegram polling error:', error);
    });
  }

  // ============ START COMMAND ============
  private async handleStart(msg: TelegramBot.Message) {
    const chatId = msg.chat.id;
    const userId = msg.from?.id?.toString();
    
    if (!userId) return;

    try {
      // Check if user exists, create if not
      let user = await storage.getUser(userId);
      if (!user) {
        user = await storage.createUser({
          id: userId,
          username: msg.from?.username,
          firstName: msg.from?.first_name,
          lastName: msg.from?.last_name,
          balance: '0.00'
        });
        
        // Send welcome message for new users
        await this.bot.sendMessage(chatId, 
          '🎉 مرحباً بك في بوت الأرقام!\n\n' +
          '✨ تم إنشاء حسابك بنجاح\n' +
          '💰 رصيدك الحالي: $0.00\n\n' +
          '📞 للحصول على رقم للتحقق، اختر الخدمة أدناه:'
        );
      }

      // Check maintenance mode
      const settings = await storage.getBotSettings();
      if (settings?.maintenanceMode) {
        await this.bot.sendMessage(chatId, 
          '🔧 ' + (settings.maintenanceMessage || 'البوت تحت الصيانة، حاول لاحقاً'));
        return;
      }

      // Check mandatory subscriptions
      const channels = await storage.getSubscriptionChannels();
      if (channels.length > 0) {
        const isSubscribed = await this.checkUserSubscriptions(userId, channels);
        if (!isSubscribed) {
          await this.showSubscriptionRequirement(chatId, channels);
          return;
        }
      }

      // Show main menu
      await this.showMainMenu(chatId, settings, user);
    } catch (error) {
      console.error('Error in handleStart:', error);
      await this.bot.sendMessage(chatId, '❌ حدث خطأ، يرجى المحاولة مرة أخرى');
    }
  }

  // ============ ADMIN COMMANDS ============
  private async handleAdminCommand(msg: TelegramBot.Message) {
    const userId = msg.from?.id?.toString();
    const chatId = msg.chat.id;

    if (userId !== ADMIN_ID) {
      await this.bot.sendMessage(chatId, '❌ غير مسموح لك بالوصول لأوامر الإدارة');
      return;
    }

    const adminKeyboard = [
      [
        { text: '👥 إدارة المستخدمين', callback_data: 'admin_users' },
        { text: '📊 الإحصائيات', callback_data: 'admin_stats' }
      ],
      [
        { text: '💸 إضافة رصيد', callback_data: 'admin_add_balance' },
        { text: '📢 رسالة جماعية', callback_data: 'admin_broadcast' }
      ],
      [
        { text: '📺 إدارة القنوات', callback_data: 'admin_channels' },
        { text: '⚙️ الإعدادات', callback_data: 'admin_settings' }
      ],
      [
        { text: '🔧 وضع الصيانة', callback_data: 'admin_maintenance' },
        { text: '📱 إضافة رقم', callback_data: 'admin_add_number' }
      ],
      [
        { text: '🔄 تحديث API', callback_data: 'admin_api' }
      ],
      [
        { text: '📋 قائمة الأوامر', callback_data: 'admin_help' }
      ]
    ];

    await this.bot.sendMessage(chatId, 
      '🔰 *لوحة تحكم الإدارة*\n\n' +
      'اختر العملية المطلوبة:', 
      {
        parse_mode: 'Markdown',
        reply_markup: { inline_keyboard: adminKeyboard }
      }
    );
  }

  private async handleBalanceCommand(msg: TelegramBot.Message, match: RegExpExecArray | null) {
    const userId = msg.from?.id?.toString();
    const chatId = msg.chat.id;

    if (userId !== ADMIN_ID) {
      await this.bot.sendMessage(chatId, '❌ غير مسموح لك بالوصول لأوامر الإدارة');
      return;
    }

    if (!match || !match[1]) {
      await this.bot.sendMessage(chatId, 
        '📝 استخدم الأمر بالشكل التالي:\n' +
        '`/balance <user_id> <amount>`\n\n' +
        'مثال: `/balance 123456789 10.50`',
        { parse_mode: 'Markdown' }
      );
      return;
    }

    const params = match[1].split(' ');
    if (params.length < 2) {
      await this.bot.sendMessage(chatId, '❌ يرجى تحديد آيدي المستخدم والمبلغ');
      return;
    }

    const targetUserId = params[0];
    const amount = params[1];

    try {
      const user = await storage.getUser(targetUserId);
      if (!user) {
        await this.bot.sendMessage(chatId, '❌ المستخدم غير موجود');
        return;
      }

      await storage.updateUserBalance(targetUserId, amount);
      
      // Create transaction record
      await storage.createTransaction({
        userId: targetUserId,
        type: parseFloat(amount) > 0 ? 'credit' : 'debit',
        amount: Math.abs(parseFloat(amount)).toString(),
        description: parseFloat(amount) > 0 ? 'Balance added by admin' : 'Balance deducted by admin',
        status: 'completed'
      });

      await this.bot.sendMessage(chatId, 
        `✅ تم تحديث رصيد المستخدم ${targetUserId}\n` +
        `💰 المبلغ: $${amount}\n` +
        `👤 المستخدم: ${user.firstName || user.username || 'غير معروف'}`
      );

      // Notify user
      try {
        await this.bot.sendMessage(parseInt(targetUserId), 
          `💰 تم ${parseFloat(amount) > 0 ? 'إضافة' : 'خصم'} $${Math.abs(parseFloat(amount))} ${parseFloat(amount) > 0 ? 'إلى' : 'من'} رصيدك`
        );
      } catch (error) {
        console.log('Could not notify user:', error);
      }
    } catch (error) {
      console.error('Error updating balance:', error);
      await this.bot.sendMessage(chatId, '❌ حدث خطأ في تحديث الرصيد');
    }
  }

  private async handleBroadcastCommand(msg: TelegramBot.Message, match: RegExpExecArray | null) {
    const userId = msg.from?.id?.toString();
    const chatId = msg.chat.id;

    if (userId !== ADMIN_ID) {
      await this.bot.sendMessage(chatId, '❌ غير مسموح لك بالوصول لأوامر الإدارة');
      return;
    }

    if (!match || !match[1]) {
      await this.bot.sendMessage(chatId, 
        '📝 استخدم الأمر بالشكل التالي:\n' +
        '`/broadcast <message>`\n\n' +
        'مثال: `/broadcast مرحباً بالجميع!`',
        { parse_mode: 'Markdown' }
      );
      return;
    }

    const message = match[1];
    await this.sendBroadcastMessage(message);
    await this.bot.sendMessage(chatId, '✅ تم إرسال الرسالة الجماعية');
  }

  private async handleDirectCommand(msg: TelegramBot.Message, match: RegExpExecArray | null) {
    const userId = msg.from?.id?.toString();
    const chatId = msg.chat.id;

    if (userId !== ADMIN_ID) {
      await this.bot.sendMessage(chatId, '❌ غير مسموح لك بالوصول لأوامر الإدارة');
      return;
    }

    if (!match || !match[1] || !match[2]) {
      await this.bot.sendMessage(chatId, 
        '📝 استخدم الأمر بالشكل التالي:\n' +
        '`/direct <user_id> <message>`\n\n' +
        'مثال: `/direct 123456789 مرحباً!`',
        { parse_mode: 'Markdown' }
      );
      return;
    }

    const targetUserId = match[1];
    const message = match[2];

    const success = await this.sendDirectMessage(targetUserId, message);
    await this.bot.sendMessage(chatId, 
      success ? '✅ تم إرسال الرسالة' : '❌ فشل في إرسال الرسالة'
    );
  }

  private async handleStatsCommand(msg: TelegramBot.Message) {
    const userId = msg.from?.id?.toString();
    const chatId = msg.chat.id;

    if (userId !== ADMIN_ID) {
      await this.bot.sendMessage(chatId, '❌ غير مسموح لك بالوصول لأوامر الإدارة');
      return;
    }

    try {
      const users = await storage.getAllUsers();
      const transactions = await storage.getAllTransactions();
      
      const totalUsers = users.length;
      const numbersReceived = transactions.filter(t => t.type === 'debit').length;
      const codesSent = transactions.filter(t => t.status === 'completed').length;
      const totalRevenue = transactions
        .filter(t => t.status === 'completed')
        .reduce((sum, t) => sum + parseFloat(t.amount || '0'), 0);

      const statsText = 
        '📊 *إحصائيات البوت*\n\n' +
        `👥 إجمالي المستخدمين: ${totalUsers}\n` +
        `📞 الأرقام المستلمة: ${numbersReceived}\n` +
        `💬 الأكواد المرسلة: ${codesSent}\n` +
        `💰 إجمالي الأرباح: $${totalRevenue.toFixed(2)}\n` +
        `📈 معدل النجاح: ${numbersReceived > 0 ? ((codesSent / numbersReceived) * 100).toFixed(1) : 0}%`;

      await this.bot.sendMessage(chatId, statsText, { parse_mode: 'Markdown' });
    } catch (error) {
      console.error('Error fetching stats:', error);
      await this.bot.sendMessage(chatId, '❌ حدث خطأ في جلب الإحصائيات');
    }
  }

  private async handleUsersCommand(msg: TelegramBot.Message) {
    const userId = msg.from?.id?.toString();
    const chatId = msg.chat.id;

    if (userId !== ADMIN_ID) {
      await this.bot.sendMessage(chatId, '❌ غير مسموح لك بالوصول لأوامر الإدارة');
      return;
    }

    try {
      const users = await storage.getAllUsers();
      let usersList = '👥 *قائمة المستخدمين (آخر 10)*\n\n';
      
      const recentUsers = users.slice(0, 10);
      for (const user of recentUsers) {
        usersList += 
          `🆔 ${user.id}\n` +
          `👤 ${user.firstName || user.username || 'غير معروف'}\n` +
          `💰 $${user.balance || '0.00'}\n` +
          `📞 ${user.numbersUsed || 0} رقم\n\n`;
      }

      if (users.length > 10) {
        usersList += `... و ${users.length - 10} مستخدم آخر`;
      }

      await this.bot.sendMessage(chatId, usersList, { parse_mode: 'Markdown' });
    } catch (error) {
      console.error('Error fetching users:', error);
      await this.bot.sendMessage(chatId, '❌ حدث خطأ في جلب قائمة المستخدمين');
    }
  }

  private async handleSettingsCommand(msg: TelegramBot.Message) {
    const userId = msg.from?.id?.toString();
    const chatId = msg.chat.id;

    if (userId !== ADMIN_ID) {
      await this.bot.sendMessage(chatId, '❌ غير مسموح لك بالوصول لأوامر الإدارة');
      return;
    }

    try {
      const settings = await storage.getBotSettings();
      
      const settingsText = 
        '⚙️ *إعدادات البوت*\n\n' +
        `🔧 وضع الصيانة: ${settings?.maintenanceMode ? 'مفعل ✅' : 'معطل ❌'}\n` +
        `💰 سعر الرقم: $${settings?.numberPrice || '0.50'}\n` +
        `🏦 الحد الأدنى للرصيد: $${settings?.minimumBalance || '1.00'}\n` +
        `📊 الحد اليومي: ${settings?.dailyLimit || 10} رقم\n` +
        `🌐 API URL: ${settings?.apiUrl || 'غير محدد'}\n\n` +
        '📝 لتغيير الإعدادات، استخدم لوحة التحكم الإدارية.';

      await this.bot.sendMessage(chatId, settingsText, { parse_mode: 'Markdown' });
    } catch (error) {
      console.error('Error fetching settings:', error);
      await this.bot.sendMessage(chatId, '❌ حدث خطأ في جلب الإعدادات');
    }
  }

  private async handleMaintenanceCommand(msg: TelegramBot.Message) {
    const userId = msg.from?.id?.toString();
    const chatId = msg.chat.id;

    if (userId !== ADMIN_ID) {
      await this.bot.sendMessage(chatId, '❌ غير مسموح لك بالوصول لأوامر الإدارة');
      return;
    }

    try {
      const settings = await storage.getBotSettings();
      const newMode = !settings?.maintenanceMode;
      
      await storage.updateBotSettings({
        maintenanceMode: newMode
      });

      await this.bot.sendMessage(chatId, 
        `🔧 تم ${newMode ? 'تفعيل' : 'إلغاء'} وضع الصيانة ${newMode ? '✅' : '❌'}`
      );
    } catch (error) {
      console.error('Error toggling maintenance:', error);
      await this.bot.sendMessage(chatId, '❌ حدث خطأ في تغيير وضع الصيانة');
    }
  }

  private async handleChannelsCommand(msg: TelegramBot.Message) {
    const userId = msg.from?.id?.toString();
    const chatId = msg.chat.id;

    if (userId !== ADMIN_ID) {
      await this.bot.sendMessage(chatId, '❌ غير مسموح لك بالوصول لأوامر الإدارة');
      return;
    }

    try {
      const channels = await storage.getSubscriptionChannels();
      
      let channelsList = '📺 *قنوات الاشتراك الإجباري*\n\n';
      
      if (channels.length === 0) {
        channelsList += 'لا توجد قنوات مضافة';
      } else {
        for (const channel of channels) {
          channelsList += 
            `📢 ${channel.name}\n` +
            `🔗 ${channel.username}\n` +
            `👥 ${channel.members || 0} عضو\n` +
            `✅ ${channel.isActive ? 'نشط' : 'غير نشط'}\n\n`;
        }
      }

      await this.bot.sendMessage(chatId, channelsList, { parse_mode: 'Markdown' });
    } catch (error) {
      console.error('Error fetching channels:', error);
      await this.bot.sendMessage(chatId, '❌ حدث خطأ في جلب قائمة القنوات');
    }
  }

  private async handleHelpCommand(msg: TelegramBot.Message) {
    const userId = msg.from?.id?.toString();
    const chatId = msg.chat.id;

    if (userId === ADMIN_ID) {
      const adminHelp = 
        '📋 *قائمة أوامر الإدارة*\n\n' +
        '🔰 `/admin` - لوحة التحكم الرئيسية\n' +
        '💰 `/balance <user_id> <amount>` - إضافة/خصم رصيد\n' +
        '📢 `/broadcast <message>` - رسالة جماعية\n' +
        '📩 `/direct <user_id> <message>` - رسالة مباشرة\n' +
        '📊 `/stats` - الإحصائيات\n' +
        '👥 `/users` - قائمة المستخدمين\n' +
        '⚙️ `/settings` - عرض الإعدادات\n' +
        '🔧 `/maintenance` - تفعيل/إلغاء الصيانة\n' +
        '📺 `/channels` - قنوات الاشتراك\n' +
        '❓ `/help` - هذه القائمة\n\n' +
        '👤 *أوامر المستخدم العادي:*\n' +
        '🏠 `/start` - القائمة الرئيسية\n' +
        '💰 `/mybalance` - رصيدي\n' +
        '👤 `/profile` - الملف الشخصي';

      await this.bot.sendMessage(chatId, adminHelp, { parse_mode: 'Markdown' });
    } else {
      const userHelp = 
        '❓ *أوامر البوت المتاحة*\n\n' +
        '🏠 `/start` - القائمة الرئيسية\n' +
        '💰 `/mybalance` - عرض رصيدي\n' +
        '👤 `/profile` - الملف الشخصي\n' +
        '❓ `/help` - هذه القائمة\n\n' +
        '📞 *للحصول على رقم:*\n' +
        'اضغط على /start واتبع الخطوات\n\n' +
        '💡 *نصائح:*\n' +
        '• تأكد من وجود رصيد كافي قبل طلب الرقم\n' +
        '• الرصيد يُخصم فقط عند استلام الكود\n' +
        '• يمكنك تغيير الرقم مجاناً قبل استلام الكود';

      await this.bot.sendMessage(chatId, userHelp, { parse_mode: 'Markdown' });
    }
  }

  // ============ USER COMMANDS ============
  private async handleMyBalanceCommand(msg: TelegramBot.Message) {
    const userId = msg.from?.id?.toString();
    const chatId = msg.chat.id;

    if (!userId) return;

    try {
      const user = await storage.getUser(userId);
      if (!user) {
        await this.bot.sendMessage(chatId, '❌ المستخدم غير موجود، استخدم /start أولاً');
        return;
      }

      const transactions = await storage.getUserTransactions(userId);
      const recentTransactions = transactions.slice(0, 5);

      let balanceText = 
        `💰 *رصيدك الحالي*\n\n` +
        `💵 الرصيد: $${user.balance || '0.00'}\n` +
        `📞 الأرقام المستخدمة: ${user.numbersUsed || 0}\n` +
        `📅 تاريخ التسجيل: ${new Date(user.createdAt || '').toLocaleDateString('ar-EG')}\n\n`;

      if (recentTransactions.length > 0) {
        balanceText += '📋 *آخر العمليات:*\n';
        for (const tx of recentTransactions) {
          const emoji = tx.type === 'credit' ? '💰' : '📞';
          const sign = tx.type === 'credit' ? '+' : '-';
          balanceText += 
            `${emoji} ${sign}$${tx.amount} - ${tx.description || 'عملية'}\n` +
            `📅 ${new Date(tx.createdAt || '').toLocaleDateString('ar-EG')}\n\n`;
        }
      }

      await this.bot.sendMessage(chatId, balanceText, { parse_mode: 'Markdown' });
    } catch (error) {
      console.error('Error fetching balance:', error);
      await this.bot.sendMessage(chatId, '❌ حدث خطأ في جلب الرصيد');
    }
  }

  private async handleProfileCommand(msg: TelegramBot.Message) {
    const userId = msg.from?.id?.toString();
    const chatId = msg.chat.id;

    if (!userId) return;

    try {
      const user = await storage.getUser(userId);
      if (!user) {
        await this.bot.sendMessage(chatId, '❌ المستخدم غير موجود، استخدم /start أولاً');
        return;
      }

      const profileText = 
        '👤 *ملفك الشخصي*\n\n' +
        `🆔 الآيدي: \`${user.id}\`\n` +
        `👤 الاسم: ${user.firstName || 'غير محدد'}\n` +
        `📱 اليوزر: ${user.username ? '@' + user.username : 'غير محدد'}\n` +
        `💰 الرصيد: $${user.balance || '0.00'}\n` +
        `📞 الأرقام المستخدمة: ${user.numbersUsed || 0}\n` +
        `📅 تاريخ التسجيل: ${new Date(user.createdAt || '').toLocaleDateString('ar-EG')}\n` +
        `🔒 حالة الحساب: ${user.isBlocked ? 'محظور ❌' : 'نشط ✅'}`;

      await this.bot.sendMessage(chatId, profileText, { parse_mode: 'Markdown' });
    } catch (error) {
      console.error('Error fetching profile:', error);
      await this.bot.sendMessage(chatId, '❌ حدث خطأ في جلب الملف الشخصي');
    }
  }

  // ============ CALLBACK QUERY HANDLER ============
  private async handleCallbackQuery(query: TelegramBot.CallbackQuery) {
    const chatId = query.message?.chat?.id;
    const userId = query.from.id.toString();
    const data = query.data;

    if (!chatId || !data) return;

    try {
      await this.bot.answerCallbackQuery(query.id);

      const [action, ...params] = data.split(':');

      switch (action) {
        // Service selection
        case 'service':
          await this.handleServiceSelection(chatId, userId, params[0]);
          break;
        
        // Country selection
        case 'country':
          await this.handleCountrySelection(chatId, userId, params[0]);
          break;
        
        // Number actions
        case 'change_number':
          await this.handleChangeNumber(chatId, userId);
          break;
        case 'change_country':
          await this.handleChangeCountry(chatId, userId);
          break;
        case 'main_menu':
          const settings = await storage.getBotSettings();
          const user = await storage.getUser(userId);
          await this.showMainMenu(chatId, settings, user);
          break;
        
        // Subscription check
        case 'check_subscription':
          await this.handleSubscriptionCheck(chatId, userId);
          break;
        
        // Admin actions
        case 'admin_users':
          await this.handleUsersCommand(query.message as TelegramBot.Message);
          break;
        case 'admin_stats':
          await this.handleStatsCommand(query.message as TelegramBot.Message);
          break;
        case 'admin_settings':
          await this.handleSettingsCommand(query.message as TelegramBot.Message);
          break;
        case 'admin_maintenance':
          await this.handleMaintenanceCommand(query.message as TelegramBot.Message);
          break;
        case 'admin_help':
          await this.handleHelpCommand(query.message as TelegramBot.Message);
          break;
        case 'admin_add_balance':
          await this.bot.sendMessage(chatId, 
            '💰 *إضافة رصيد*\n\n' +
            'استخدم الأمر التالي:\n' +
            '`/balance <user_id> <amount>`\n\n' +
            'مثال: `/balance 123456789 10.50`',
            { parse_mode: 'Markdown' }
          );
          break;
        case 'admin_broadcast':
          await this.bot.sendMessage(chatId, 
            '📢 *رسالة جماعية*\n\n' +
            'استخدم الأمر التالي:\n' +
            '`/broadcast <message>`\n\n' +
            'مثال: `/broadcast مرحباً بالجميع!`',
            { parse_mode: 'Markdown' }
          );
          break;
        case 'admin_channels':
          await this.handleChannelsCommand(query.message as TelegramBot.Message);
          break;
        case 'admin_api':
          await this.bot.sendMessage(chatId, 
            '🔄 *تحديث API*\n\n' +
            `📡 API الحالي: \`${API_BASE_URL}\`\n\n` +
            '⚙️ يمكنك تحديث API من لوحة التحكم الويب\n' +
            'أو التواصل مع المطور لتغيير API',
            { parse_mode: 'Markdown' }
          );
          break;
      }
    } catch (error) {
      console.error('Error in handleCallbackQuery:', error);
      await this.bot.sendMessage(chatId, '❌ حدث خطأ، يرجى المحاولة مرة أخرى');
    }
  }

  // ============ MAIN MENU ============
  private async showMainMenu(chatId: number, settings?: any, user?: any) {
    const services = settings?.supportedServices || ['whatsapp', 'telegram', 'facebook', 'instagram', 'twitter'];
    const welcomeMessage = settings?.welcomeMessage || 'مرحباً بك في بوت الأرقام! 🤖\nاختر الخدمة المطلوبة:';

    const serviceEmojis: { [key: string]: string } = {
      whatsapp: '📱',
      telegram: '💬',
      facebook: '📘',
      instagram: '📷',
      twitter: '🐦'
    };

    const keyboard = [];
    
    // Add services in rows of 2
    for (let i = 0; i < services.length; i += 2) {
      const row = [];
      row.push({
        text: `${serviceEmojis[services[i]] || '📱'} ${services[i].charAt(0).toUpperCase() + services[i].slice(1)}`,
        callback_data: `service:${services[i]}`
      });
      
      if (i + 1 < services.length) {
        row.push({
          text: `${serviceEmojis[services[i + 1]] || '📱'} ${services[i + 1].charAt(0).toUpperCase() + services[i + 1].slice(1)}`,
          callback_data: `service:${services[i + 1]}`
        });
      }
      keyboard.push(row);
    }

    // Add user info and help buttons
    keyboard.push([
      { text: '💰 رصيدي', callback_data: 'my_balance' },
      { text: '👤 ملفي الشخصي', callback_data: 'my_profile' }
    ]);
    keyboard.push([
      { text: '❓ المساعدة', callback_data: 'help' }
    ]);

    let fullMessage = welcomeMessage;
    if (user) {
      fullMessage += `\n\n👤 مرحباً ${user.firstName || user.username || 'صديقي'}!`;
      fullMessage += `\n💰 رصيدك: $${user.balance || '0.00'}`;
    }

    await this.bot.sendMessage(chatId, fullMessage, {
      reply_markup: {
        inline_keyboard: keyboard
      }
    });
  }

  // ============ SERVICE & COUNTRY SELECTION ============
  private async handleServiceSelection(chatId: number, userId: string, service: string) {
    // Store selected service in session
    let session = this.userSessions.get(userId) || {};
    session.service = service;
    this.userSessions.set(userId, session);

    const settings = await storage.getBotSettings();
    const countries = settings?.supportedCountries || [
      {code: "EG", name: "مصر", flag: "🇪🇬"},
      {code: "SA", name: "السعودية", flag: "🇸🇦"},
      {code: "AE", name: "الإمارات", flag: "🇦🇪"},
      {code: "US", name: "أمريكا", flag: "🇺🇸"},
      {code: "GB", name: "بريطانيا", flag: "🇬🇧"},
      {code: "DE", name: "ألمانيا", flag: "🇩🇪"}
    ];

    const keyboard = [];
    
    // Add countries in rows of 2
    if (Array.isArray(countries)) {
      for (let i = 0; i < countries.length; i += 2) {
        const row = [];
        row.push({
          text: `${countries[i].flag} ${countries[i].name}`,
          callback_data: `country:${countries[i].code}`
        });
        
        if (i + 1 < countries.length) {
          row.push({
            text: `${countries[i + 1].flag} ${countries[i + 1].name}`,
            callback_data: `country:${countries[i + 1].code}`
          });
        }
        keyboard.push(row);
      }
    }

    keyboard.push([
      { text: '🔙 رجوع للقائمة الرئيسية', callback_data: 'main_menu' }
    ]);

    await this.bot.sendMessage(chatId, 
      `📱 تم اختيار ${service.toUpperCase()}\n\n🌍 اختر الدولة:`, 
      {
        reply_markup: { inline_keyboard: keyboard }
      }
    );
  }

  private async handleCountrySelection(chatId: number, userId: string, countryCode: string) {
    let session = this.userSessions.get(userId) || {};
    session.country = countryCode;
    this.userSessions.set(userId, session);

    // Check user balance
    const user = await storage.getUser(userId);
    const settings = await storage.getBotSettings();
    const numberPrice = parseFloat(settings?.numberPrice || '0.50');
    const minimumBalance = parseFloat(settings?.minimumBalance || '1.00');

    if (!user || parseFloat(user.balance || '0') < minimumBalance) {
      await this.bot.sendMessage(chatId, 
        `💸 رصيدك غير كافي!\n\n` +
        `💰 سعر الرقم: $${numberPrice}\n` +
        `🏦 الحد الأدنى المطلوب: $${minimumBalance}\n` +
        `💵 رصيدك الحالي: $${user?.balance || '0.00'}\n\n` +
        `📞 تواصل مع الإدارة لشحن رصيدك`
      );
      return;
    }

    await this.getPhoneNumber(chatId, userId, session.service, countryCode);
  }

  // ============ PHONE NUMBER OPERATIONS ============
  private async getPhoneNumber(chatId: number, userId: string, service: string, countryCode: string) {
    try {
      const settings = await storage.getBotSettings();
      
      // Create transaction record
      const transaction = await storage.createTransaction({
        userId,
        type: 'debit',
        amount: settings?.numberPrice || '0.50',
        description: `Phone number for ${service} - ${countryCode}`,
        service,
        country: countryCode,
        status: 'pending'
      });

      // Show loading message
      const loadingMsg = await this.bot.sendMessage(chatId, 
        '⏳ جاري البحث عن رقم متاح...\n\n' +
        '🔍 يرجى الانتظار...'
      );

      // Call external API to get phone number
      const phoneNumber = await this.fetchPhoneNumberFromAPI(service, countryCode);
      
      if (!phoneNumber) {
        await this.bot.editMessageText(
          '❌ عذراً، لا توجد أرقام متاحة حالياً\n\n' +
          '🔄 يرجى المحاولة لاحقاً أو اختيار دولة أخرى', 
          {
            chat_id: chatId,
            message_id: loadingMsg.message_id
          }
        );
        
        // Update transaction as failed
        await storage.updateTransactionStatus(transaction.id, 'failed');
        return;
      }

      // Update transaction with phone number
      await storage.updateTransactionStatus(transaction.id, 'pending');
      
      // Store phone number in session
      let session = this.userSessions.get(userId) || {};
      session.phoneNumber = phoneNumber;
      session.transactionId = transaction.id;
      this.userSessions.set(userId, session);

      const keyboard = [
        [
          { text: '🔄 تغيير الرقم', callback_data: 'change_number' },
          { text: '🌍 تغيير الدولة', callback_data: 'change_country' }
        ],
        [
          { text: '🔙 القائمة الرئيسية', callback_data: 'main_menu' }
        ]
      ];

      // Edit the loading message with the phone number
      await this.bot.editMessageText(
        `📞 *تم العثور على رقم!*\n\n` +
        `🌍 الدولة: ${this.getCountryName(countryCode)}\n` +
        `📱 الخدمة: ${service.toUpperCase()}\n` +
        `🔢 الرقم: \`${phoneNumber}\`\n\n` +
        `⏰ انتظار استلام الكود...\n` +
        `💡 *هام:* الرصيد سيُخصم فقط عند وصول الكود`, 
        {
          chat_id: chatId,
          message_id: loadingMsg.message_id,
          parse_mode: 'Markdown',
          reply_markup: { inline_keyboard: keyboard }
        }
      );

      // Start polling for SMS code
      this.pollForSMSCode(chatId, userId, phoneNumber, transaction.id);

    } catch (error) {
      console.error('Error getting phone number:', error);
      await this.bot.sendMessage(chatId, 
        '❌ حدث خطأ في الحصول على الرقم\n\n' +
        '🔄 يرجى المحاولة مرة أخرى'
      );
    }
  }

  private async fetchPhoneNumberFromAPI(service: string, countryCode: string): Promise<string | null> {
    try {
      const settings = await storage.getBotSettings();
      const apiUrl = settings?.apiUrl || API_BASE_URL;
      
      // طلب رقم من API
      const response = await axios.post(`${apiUrl}/get-number`, {
        service,
        country: countryCode
      }, {
        headers: {
          'Content-Type': 'application/json'
        },
        timeout: 30000
      });

      // إرجاع الرقم المستلم من API
      return response.data.phone_number || response.data.number || response.data.phone;
    } catch (error) {
      console.error('API Error:', error);
      return null;
    }
  }

  private async pollForSMSCode(chatId: number, userId: string, phoneNumber: string, transactionId: string) {
    let attempts = 0;
    const maxAttempts = 120; // 10 minutes with 5-second intervals
    const pollId = `${userId}_${transactionId}`;

    const poll = async () => {
      if (attempts >= maxAttempts) {
        // Timeout - no code received
        await this.bot.sendMessage(chatId, 
          '⏰ *انتهت مهلة انتظار الكود*\n\n' +
          '❌ لم يصل كود التحقق خلال 10 دقائق\n' +
          '💰 لم يتم خصم أي رصيد من حسابك\n\n' +
          '🔄 يمكنك المحاولة مرة أخرى بعد قليل', 
          { parse_mode: 'Markdown' }
        );
        
        await storage.updateTransactionStatus(transactionId, 'failed');
        this.userSessions.delete(userId);
        this.activePolls.delete(pollId);
        return;
      }

      attempts++;
      
      try {
        const code = await this.checkForSMSCode(phoneNumber);
        
        if (code) {
          // Code received successfully
          const user = await storage.getUser(userId);
          const settings = await storage.getBotSettings();
          const price = settings?.numberPrice || '0.50';
          
          // Deduct balance
          await storage.updateUserBalance(userId, `-${price}`);
          
          // Update transaction
          await storage.updateTransactionStatus(transactionId, 'completed', code);
          
          // Update user's numbers used count
          if (user) {
            await storage.createTransaction({
              userId,
              type: 'debit',
              amount: price,
              description: 'SMS verification code received',
              status: 'completed'
            });
          }

          // Send success message
          await this.bot.sendMessage(chatId, 
            `✅ *تم استلام الكود بنجاح!*\n\n` +
            `📞 الرقم: \`${phoneNumber}\`\n` +
            `🔐 الكود: \`${code}\`\n\n` +
            `💰 تم خصم $${price} من رصيدك\n` +
            `💵 رصيدك الجديد: $${(parseFloat(user?.balance || '0') - parseFloat(price)).toFixed(2)}\n\n` +
            `🎉 شكراً لاستخدام البوت!`, 
            { 
              parse_mode: 'Markdown',
              reply_markup: {
                inline_keyboard: [
                  [{ text: '🔙 القائمة الرئيسية', callback_data: 'main_menu' }]
                ]
              }
            }
          );

          // Clean up session
          this.userSessions.delete(userId);
          this.activePolls.delete(pollId);
          
        } else {
          // Continue polling
          const timeout = setTimeout(poll, 5000);
          this.activePolls.set(pollId, timeout);
          
          // Send periodic updates
          if (attempts % 12 === 0) { // Every minute
            const remainingMinutes = Math.floor((maxAttempts - attempts) * 5 / 60);
            await this.bot.sendMessage(chatId, 
              `⏳ لا يزال في انتظار الكود...\n` +
              `⏰ الوقت المتبقي: ${remainingMinutes} دقيقة تقريباً`
            );
          }
        }
      } catch (error) {
        console.error('Error polling for SMS:', error);
        const timeout = setTimeout(poll, 5000);
        this.activePolls.set(pollId, timeout);
      }
    };

    // Start polling
    const timeout = setTimeout(poll, 5000);
    this.activePolls.set(pollId, timeout);
  }

  private async checkForSMSCode(phoneNumber: string): Promise<string | null> {
    try {
      const settings = await storage.getBotSettings();
      const apiUrl = settings?.apiUrl || API_BASE_URL;
      
      if (!apiUrl) {
        // For testing, simulate receiving a code after some attempts
        if (Math.random() > 0.7) {
          return Math.floor(100000 + Math.random() * 900000).toString();
        }
        return null;
      }

      const response = await axios.get(`${apiUrl}/get-sms`, {
        params: { phone_number: phoneNumber },
        headers: {
          'Content-Type': 'application/json'
        },
        timeout: 10000
      });

      return response.data.code || response.data.sms || null;
    } catch (error) {
      console.error('SMS Check Error:', error);
      
      // Fallback for testing
      if (Math.random() > 0.8) {
        return Math.floor(100000 + Math.random() * 900000).toString();
      }
      return null;
    }
  }

  // ============ SUBSCRIPTION MANAGEMENT ============
  private async checkUserSubscriptions(userId: string, channels: any[]): Promise<boolean> {
    for (const channel of channels) {
      try {
        const member = await this.bot.getChatMember(
          channel.chatId || channel.username, 
          parseInt(userId)
        );
        if (member.status === 'left' || member.status === 'kicked') {
          return false;
        }
      } catch (error) {
        console.error('Error checking subscription:', error);
        return false;
      }
    }
    return true;
  }

  private async showSubscriptionRequirement(chatId: number, channels: any[]) {
    let message = '🔒 *للاستمرار في استخدام البوت*\n\n';
    message += 'يجب الاشتراك في القنوات التالية أولاً:\n\n';
    
    const keyboard = [];
    
    for (const channel of channels) {
      message += `📢 ${channel.name}\n`;
      keyboard.push([{
        text: `📢 الانضمام إلى ${channel.name}`,
        url: `https://t.me/${channel.username.replace('@', '')}`
      }]);
    }

    keyboard.push([{
      text: '✅ تحقق من الاشتراك',
      callback_data: 'check_subscription'
    }]);

    await this.bot.sendMessage(chatId, message, {
      parse_mode: 'Markdown',
      reply_markup: { inline_keyboard: keyboard }
    });
  }

  private async handleSubscriptionCheck(chatId: number, userId: string) {
    const channels = await storage.getSubscriptionChannels();
    const isSubscribed = await this.checkUserSubscriptions(userId, channels);
    
    if (isSubscribed) {
      await this.bot.sendMessage(chatId, '✅ تم التحقق من الاشتراك بنجاح!');
      const settings = await storage.getBotSettings();
      const user = await storage.getUser(userId);
      await this.showMainMenu(chatId, settings, user);
    } else {
      await this.bot.sendMessage(chatId, 
        '❌ يرجى الاشتراك في جميع القنوات المطلوبة أولاً\n\n' +
        '✅ بعد الاشتراك، اضغط على "تحقق من الاشتراك" مرة أخرى'
      );
    }
  }

  // ============ UTILITY METHODS ============
  private async handleChangeNumber(chatId: number, userId: string) {
    const session = this.userSessions.get(userId);
    if (session?.service && session?.country) {
      // Cancel current polling
      const pollId = `${userId}_${session.transactionId}`;
      const timeout = this.activePolls.get(pollId);
      if (timeout) {
        clearTimeout(timeout);
        this.activePolls.delete(pollId);
      }
      
      // Mark old transaction as cancelled
      if (session.transactionId) {
        await storage.updateTransactionStatus(session.transactionId, 'failed');
      }
      
      await this.bot.sendMessage(chatId, '🔄 جاري الحصول على رقم جديد...');
      await this.getPhoneNumber(chatId, userId, session.service, session.country);
    }
  }

  private async handleChangeCountry(chatId: number, userId: string) {
    const session = this.userSessions.get(userId);
    if (session?.service) {
      // Cancel current polling
      const pollId = `${userId}_${session.transactionId}`;
      const timeout = this.activePolls.get(pollId);
      if (timeout) {
        clearTimeout(timeout);
        this.activePolls.delete(pollId);
      }
      
      // Mark old transaction as cancelled
      if (session.transactionId) {
        await storage.updateTransactionStatus(session.transactionId, 'failed');
      }
      
      await this.handleServiceSelection(chatId, userId, session.service);
    }
  }

  private getCountryName(countryCode: string): string {
    const countries: { [key: string]: string } = {
      'EG': 'مصر 🇪🇬',
      'SA': 'السعودية 🇸🇦',
      'AE': 'الإمارات 🇦🇪',
      'US': 'أمريكا 🇺🇸',
      'GB': 'بريطانيا 🇬🇧',
      'DE': 'ألمانيا 🇩🇪'
    };
    return countries[countryCode] || `${countryCode} 🌍`;
  }

  // ============ PUBLIC METHODS FOR ADMIN OPERATIONS ============
  async sendBroadcastMessage(content: string): Promise<void> {
    const users = await storage.getAllUsers();
    let sentCount = 0;
    let failedCount = 0;

    for (const user of users) {
      try {
        await this.bot.sendMessage(parseInt(user.id), content);
        sentCount++;
        
        // Add delay to prevent flooding
        await new Promise(resolve => setTimeout(resolve, 50));
      } catch (error) {
        console.error(`Failed to send message to ${user.id}:`, error);
        failedCount++;
      }
    }

    console.log(`Broadcast sent: ${sentCount} successful, ${failedCount} failed`);
  }

  async sendDirectMessage(userId: string, content: string): Promise<boolean> {
    try {
      await this.bot.sendMessage(parseInt(userId), content);
      return true;
    } catch (error) {
      console.error(`Failed to send direct message to ${userId}:`, error);
      return false;
    }
  }

  // Handle manual number addition command
  private async handleAddNumberCommand(msg: TelegramBot.Message, match: RegExpExecArray | null) {
    const userId = msg.from?.id?.toString();
    const chatId = msg.chat.id;

    if (userId !== ADMIN_ID) {
      await this.bot.sendMessage(chatId, '❌ غير مسموح لك بالوصول لأوامر الإدارة');
      return;
    }

    if (!match || !match[1]) {
      await this.bot.sendMessage(chatId, 
        '📱 *إضافة رقم يدوياً*\n\n' +
        'الاستخدام: `/addnumber +201234567890`\n\n' +
        '💡 ملاحظة: الرقم سيتم إضافته لنظام البحث عن الأكواد',
        { parse_mode: 'Markdown' }
      );
      return;
    }

    const phoneNumber = match[1].trim();
    
    // Validate phone number format
    if (!phoneNumber.match(/^\+\d{10,15}$/)) {
      await this.bot.sendMessage(chatId, '❌ تنسيق الرقم غير صحيح. استخدم التنسيق: +201234567890');
      return;
    }

    try {
      // Start polling for SMS codes for this number
      await this.bot.sendMessage(chatId, 
        `✅ تم إضافة الرقم: \`${phoneNumber}\`\n\n` +
        '🔍 جاري البحث عن أكواد التحقق...\n' +
        '⏱️ سيتم البحث لمدة 10 دقائق',
        { parse_mode: 'Markdown' }
      );
      
      // Start polling for codes
      this.startManualNumberPolling(chatId, phoneNumber);
      
    } catch (error) {
      console.error('Error adding manual number:', error);
      await this.bot.sendMessage(chatId, '❌ حدث خطأ في إضافة الرقم');
    }
  }

  // Start polling for manually added number
  private async startManualNumberPolling(chatId: number, phoneNumber: string) {
    let attempts = 0;
    const maxAttempts = 120; // 10 minutes with 5-second intervals
    
    const pollForCode = async () => {
      try {
        attempts++;
        
        if (attempts > maxAttempts) {
          await this.bot.sendMessage(chatId, 
            `⏰ انتهت مهلة البحث للرقم: \`${phoneNumber}\`\n\n` +
            '❌ لم يتم العثور على أي كود خلال 10 دقائق',
            { parse_mode: 'Markdown' }
          );
          return;
        }

        // Check for SMS codes via API
        const settings = await storage.getBotSettings();
        const apiUrl = settings?.apiUrl || API_BASE_URL;
        
        const response = await axios.get(`${apiUrl}/get-sms`, {
          params: {
            phone_number: phoneNumber
          },
          timeout: 10000
        });

        if (response.data && response.data.code) {
          // Code found!
          await this.bot.sendMessage(chatId,
            `✅ تم العثور على كود للرقم: \`${phoneNumber}\`\n\n` +
            `🔢 الكود: \`${response.data.code}\`\n\n` +
            '📋 انسخ الكود واستخدمه للتحقق',
            { 
              parse_mode: 'Markdown',
              reply_markup: {
                inline_keyboard: [
                  [{ text: '📋 نسخ الكود', callback_data: `copy_code_${response.data.code}` }]
                ]
              }
            }
          );
          
          // Create transaction record
          await storage.createTransaction({
            userId: ADMIN_ID,
            type: 'manual_number',
            phoneNumber: phoneNumber,
            code: response.data.code,
            status: 'completed',
            service: 'manual',
            country: 'unknown',
            amount: '0.00'
          });
          
          return;
        }
        
        // Continue polling
        setTimeout(pollForCode, 5000); // Check every 5 seconds
        
      } catch (error) {
        console.error('Error polling for manual SMS code:', error);
        
        // Continue polling even on error
        if (attempts < maxAttempts) {
          setTimeout(pollForCode, 5000);
        } else {
          await this.bot.sendMessage(chatId, 
            `❌ حدث خطأ في البحث عن الكود للرقم: \`${phoneNumber}\``,
            { parse_mode: 'Markdown' }
          );
        }
      }
    };

    // Start polling
    pollForCode();
  }

  // Graceful shutdown
  stopBot(): void {
    // Clear all active polls
    const timeouts = Array.from(this.activePolls.values());
    for (const timeout of timeouts) {
      clearTimeout(timeout);
    }
    this.activePolls.clear();
    
    // Stop bot polling
    this.bot.stopPolling();
  }
}

export const telegramBot = new TelegramBotService();

// Handle process termination
process.on('SIGINT', () => {
  console.log('Stopping Telegram bot...');
  telegramBot.stopBot();
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('Stopping Telegram bot...');
  telegramBot.stopBot();
  process.exit(0);
});