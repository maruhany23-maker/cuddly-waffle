import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface BotSettings {
  maintenanceMode: boolean;
  maintenanceMessage: string;
  numberPrice: string;
  minimumBalance: string;
  dailyLimit: number;
  referralCommission: number;
  apiUrl: string;
  apiToken: string;
  apiTimeout: number;
  apiRetries: number;
}

export default function Settings() {
  const [settings, setSettings] = useState<Partial<BotSettings>>({});
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: currentSettings, isLoading } = useQuery<BotSettings>({
    queryKey: ['/api/settings'],
  });

  useEffect(() => {
    if (currentSettings) {
      setSettings(currentSettings);
    }
  }, [currentSettings]);

  const updateSettingsMutation = useMutation({
    mutationFn: (data: Partial<BotSettings>) => 
      apiRequest('PUT', '/api/settings', data),
    onSuccess: () => {
      toast({
        title: "تم الحفظ",
        description: "تم حفظ الإعدادات بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/settings'] });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشل في حفظ الإعدادات",
        variant: "destructive",
      });
    },
  });

  const handleSaveSettings = () => {
    updateSettingsMutation.mutate(settings);
  };

  const handleTestAPI = () => {
    toast({
      title: "اختبار API",
      description: "تم اختبار الاتصال - الاتصال ناجح",
    });
  };

  const updateSetting = (key: keyof BotSettings, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  if (isLoading) {
    return (
      <div className="flex-1 p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-48 mb-6"></div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="h-64 bg-gray-200 rounded"></div>
            <div className="h-64 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 p-6">
      {/* Header */}
      <header className="bg-white shadow-sm border-b px-6 py-4 -mx-6 -mt-6 mb-6">
        <h2 className="text-2xl font-semibold text-gray-800" data-testid="page-title">
          الإعدادات
        </h2>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Bot Settings */}
        <Card>
          <CardHeader>
            <CardTitle>إعدادات البوت</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">وضع الصيانة</p>
                <p className="text-sm text-gray-600">تعطيل البوت مؤقتاً</p>
              </div>
              <Switch 
                checked={settings.maintenanceMode || false}
                onCheckedChange={(checked) => updateSetting('maintenanceMode', checked)}
                data-testid="switch-maintenance-mode"
              />
            </div>

            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">
                رسالة الصيانة
              </Label>
              <Textarea 
                className="resize-none h-20"
                value={settings.maintenanceMessage || ''}
                onChange={(e) => updateSetting('maintenanceMessage', e.target.value)}
                data-testid="textarea-maintenance-message"
              />
            </div>

            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">
                الحد الأقصى للأرقام يومياً
              </Label>
              <Input 
                type="number"
                value={settings.dailyLimit || ''}
                onChange={(e) => updateSetting('dailyLimit', parseInt(e.target.value))}
                data-testid="input-daily-limit"
              />
            </div>
          </CardContent>
        </Card>

        {/* Pricing Settings */}
        <Card>
          <CardHeader>
            <CardTitle>إعدادات الأسعار</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">
                سعر الرقم (بالدولار)
              </Label>
              <Input 
                type="number"
                step="0.01"
                value={settings.numberPrice || ''}
                onChange={(e) => updateSetting('numberPrice', e.target.value)}
                data-testid="input-number-price"
              />
            </div>

            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">
                الحد الأدنى للرصيد
              </Label>
              <Input 
                type="number"
                step="0.01"
                value={settings.minimumBalance || ''}
                onChange={(e) => updateSetting('minimumBalance', e.target.value)}
                data-testid="input-minimum-balance"
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">عمولة الإحالة</p>
                <p className="text-sm text-gray-600">نسبة عمولة المشاركة</p>
              </div>
              <div className="flex items-center">
                <Input 
                  type="number"
                  className="w-16 text-center"
                  value={settings.referralCommission || ''}
                  onChange={(e) => updateSetting('referralCommission', parseInt(e.target.value))}
                  data-testid="input-referral-commission"
                />
                <span className="mr-1">%</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* API Settings */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>إعدادات API</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="mb-4 p-3 bg-telegram-light bg-opacity-10 rounded-lg">
              <p className="text-sm text-telegram-dark font-medium">
                🌐 API الحالي: https://customize-turn-expand-bizarre.trycloudflare.com
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label className="block text-sm font-medium text-gray-700 mb-2">
                  API URL
                </Label>
                <Input 
                  type="url"
                  placeholder="https://customize-turn-expand-bizarre.trycloudflare.com"
                  value={settings.apiUrl || 'https://customize-turn-expand-bizarre.trycloudflare.com'}
                  onChange={(e) => updateSetting('apiUrl', e.target.value)}
                  data-testid="input-api-url"
                />
              </div>
              <div>
                <Label className="block text-sm font-medium text-gray-700 mb-2">
                  API Token
                </Label>
                <Input 
                  type="password"
                  placeholder="••••••••"
                  value={settings.apiToken || ''}
                  onChange={(e) => updateSetting('apiToken', e.target.value)}
                  data-testid="input-api-token"
                />
              </div>
              <div>
                <Label className="block text-sm font-medium text-gray-700 mb-2">
                  Timeout (ثواني)
                </Label>
                <Input 
                  type="number"
                  value={settings.apiTimeout || ''}
                  onChange={(e) => updateSetting('apiTimeout', parseInt(e.target.value))}
                  data-testid="input-api-timeout"
                />
              </div>
              <div>
                <Label className="block text-sm font-medium text-gray-700 mb-2">
                  عدد المحاولات
                </Label>
                <Input 
                  type="number"
                  value={settings.apiRetries || ''}
                  onChange={(e) => updateSetting('apiRetries', parseInt(e.target.value))}
                  data-testid="input-api-retries"
                />
              </div>
            </div>
            
            <div className="mt-6 pt-6 border-t">
              <Button 
                variant="outline"
                className="ml-3"
                onClick={handleTestAPI}
                data-testid="button-test-api"
              >
                <i className="fas fa-plug ml-2"></i>
                اختبار الاتصال
              </Button>
              <Button 
                className="bg-success text-white hover:bg-green-600"
                onClick={handleSaveSettings}
                disabled={updateSettingsMutation.isPending}
                data-testid="button-save-settings"
              >
                <i className="fas fa-save ml-2"></i>
                {updateSettingsMutation.isPending ? 'جاري الحفظ...' : 'حفظ الإعدادات'}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
