import { useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface AddBalanceModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  userId?: string;
}

export default function AddBalanceModal({ open, onOpenChange, userId = "" }: AddBalanceModalProps) {
  const [targetUserId, setTargetUserId] = useState(userId);
  const [amount, setAmount] = useState("");
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  useEffect(() => {
    setTargetUserId(userId);
  }, [userId]);

  const { data: user } = useQuery({
    queryKey: [`/api/users/${targetUserId}`],
    enabled: !!targetUserId && open,
  });

  const updateBalanceMutation = useMutation({
    mutationFn: ({ userId, amount }: { userId: string; amount: string }) =>
      apiRequest('POST', `/api/users/${userId}/balance`, { amount }),
    onSuccess: () => {
      toast({
        title: "تم التحديث",
        description: "تم تحديث الرصيد بنجاح",
      });
      setAmount("");
      setTargetUserId("");
      onOpenChange(false);
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] });
    },
    onError: () => {
      toast({
        title: "خطأ",
        description: "فشل في تحديث الرصيد",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetUserId.trim() || !amount.trim() || isNaN(parseFloat(amount))) {
      toast({
        title: "خطأ",
        description: "يرجى ملء جميع الحقول بشكل صحيح",
        variant: "destructive",
      });
      return;
    }

    updateBalanceMutation.mutate({ userId: targetUserId, amount });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <i className="fas fa-plus-circle text-success ml-2"></i>
            إضافة رصيد
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label className="block text-sm font-medium text-gray-700 mb-2">
              آيدي المستخدم
            </Label>
            <Input 
              placeholder="@username أو User ID"
              value={targetUserId}
              onChange={(e) => setTargetUserId(e.target.value)}
              data-testid="input-user-id"
            />
          </div>
          
          {user && (
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">
                الرصيد الحالي
              </Label>
              <div className="px-3 py-2 bg-gray-100 rounded-lg" data-testid="text-current-balance">
                ${user.balance || '0.00'}
              </div>
            </div>
          )}
          
          <div>
            <Label className="block text-sm font-medium text-gray-700 mb-2">
              المبلغ (استخدم - للخصم)
            </Label>
            <Input 
              type="number"
              step="0.01"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              data-testid="input-amount"
            />
          </div>
          
          <div className="flex space-x-3 space-x-reverse">
            <Button 
              type="button" 
              variant="outline" 
              className="flex-1"
              onClick={() => onOpenChange(false)}
              data-testid="button-cancel"
            >
              إلغاء
            </Button>
            <Button 
              type="submit" 
              className="flex-1 bg-success text-white hover:bg-green-600"
              disabled={updateBalanceMutation.isPending}
              data-testid="button-submit"
            >
              {updateBalanceMutation.isPending ? 'جاري التحديث...' : 'تحديث الرصيد'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
