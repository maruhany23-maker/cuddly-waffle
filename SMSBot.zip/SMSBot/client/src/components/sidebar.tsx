import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

const navigation = [
  { 
    name: 'لوحة التحكم', 
    href: '/', 
    icon: 'fas fa-tachometer-alt',
    section: 'dashboard'
  },
  { 
    name: 'إدارة المستخدمين', 
    href: '/users', 
    icon: 'fas fa-users',
    section: 'users'
  },
  { 
    name: 'الإحصائيات', 
    href: '/statistics', 
    icon: 'fas fa-chart-bar',
    section: 'statistics'
  },
  { 
    name: 'الرسائل', 
    href: '/messaging', 
    icon: 'fas fa-paper-plane',
    section: 'messaging'
  },
  { 
    name: 'قنوات الاشتراك', 
    href: '/channels', 
    icon: 'fas fa-broadcast-tower',
    section: 'channels'
  },
  { 
    name: 'الإعدادات', 
    href: '/settings', 
    icon: 'fas fa-cog',
    section: 'settings'
  },
];

export default function Sidebar() {
  const [location] = useLocation();

  return (
    <div className="w-64 bg-telegram-dark text-white flex-shrink-0">
      <div className="p-6">
        <div className="flex items-center space-x-3 space-x-reverse mb-8">
          <i className="fas fa-robot text-2xl"></i>
          <h1 className="text-xl font-bold">Number Bot</h1>
        </div>
        
        <nav className="space-y-2">
          {navigation.map((item) => {
            const isActive = location === item.href || 
              (item.href !== '/' && location.startsWith(item.href));
            
            return (
              <Link 
                key={item.href} 
                href={item.href}
                data-testid={`nav-${item.section}`}
              >
                <div className={cn(
                  "nav-item flex items-center space-x-3 space-x-reverse px-4 py-3 rounded-lg text-white hover:bg-white hover:bg-opacity-10 transition-colors cursor-pointer",
                  isActive && "bg-white bg-opacity-20"
                )}>
                  <i className={item.icon}></i>
                  <span>{item.name}</span>
                </div>
              </Link>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
