import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface BotInterfaceProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function BotInterface({ open, onOpenChange }: BotInterfaceProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center text-telegram-blue">
            <i className="fas fa-comments ml-2"></i>
            محاكي واجهة البوت
          </DialogTitle>
          <p className="text-sm text-gray-600">معاينة تفاعل المستخدم مع البوت</p>
        </DialogHeader>
        
        {/* Chat Interface */}
        <div className="bg-gray-50 rounded-lg p-4 h-96 overflow-y-auto space-y-4">
          {/* Bot Welcome Message */}
          <div className="flex">
            <div className="bg-white rounded-lg p-3 max-w-xs shadow-sm">
              <p className="text-sm mb-2">مرحباً بك في بوت الأرقام! 🤖</p>
              <p className="text-sm mb-3">اختر الخدمة المطلوبة:</p>
              
              <div className="space-y-2">
                <Button 
                  size="sm" 
                  className="w-full bg-telegram-blue text-white hover:bg-telegram-dark"
                  data-testid="demo-service-whatsapp"
                >
                  📱 WhatsApp
                </Button>
                <Button 
                  size="sm" 
                  className="w-full bg-telegram-blue text-white hover:bg-telegram-dark"
                  data-testid="demo-service-telegram"
                >
                  💬 Telegram
                </Button>
                <Button 
                  size="sm" 
                  className="w-full bg-telegram-blue text-white hover:bg-telegram-dark"
                  data-testid="demo-service-facebook"
                >
                  📘 Facebook
                </Button>
                <Button 
                  size="sm" 
                  className="w-full bg-telegram-blue text-white hover:bg-telegram-dark"
                  data-testid="demo-service-instagram"
                >
                  📷 Instagram
                </Button>
                <Button 
                  size="sm" 
                  className="w-full bg-telegram-blue text-white hover:bg-telegram-dark"
                  data-testid="demo-service-twitter"
                >
                  🐦 Twitter
                </Button>
              </div>
            </div>
          </div>

          {/* User Selection */}
          <div className="flex justify-end">
            <div className="bg-telegram-light text-white rounded-lg p-3 max-w-xs">
              <p className="text-sm">📱 WhatsApp</p>
            </div>
          </div>

          {/* Country Selection */}
          <div className="flex">
            <div className="bg-white rounded-lg p-3 max-w-xs shadow-sm">
              <p className="text-sm mb-3">اختر الدولة:</p>
              <div className="grid grid-cols-2 gap-2">
                <Button 
                  variant="secondary" 
                  size="sm"
                  data-testid="demo-country-egypt"
                >
                  🇪🇬 مصر
                </Button>
                <Button 
                  variant="secondary" 
                  size="sm"
                  data-testid="demo-country-saudi"
                >
                  🇸🇦 السعودية
                </Button>
                <Button 
                  variant="secondary" 
                  size="sm"
                  data-testid="demo-country-uae"
                >
                  🇦🇪 الإمارات
                </Button>
                <Button 
                  variant="secondary" 
                  size="sm"
                  data-testid="demo-country-usa"
                >
                  🇺🇸 أمريكا
                </Button>
              </div>
            </div>
          </div>

          {/* Number Display */}
          <div className="flex">
            <div className="bg-white rounded-lg p-3 max-w-md shadow-sm">
              <p className="text-sm mb-2">تم العثور على رقم:</p>
              <div className="bg-gray-100 p-2 rounded mb-3 font-mono text-center" data-testid="demo-phone-number">
                +20123456789
              </div>
              <div className="grid grid-cols-3 gap-2">
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="text-xs bg-warning text-white hover:bg-orange-600"
                  data-testid="demo-change-number"
                >
                  🔄 تغيير الرقم
                </Button>
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="text-xs"
                  data-testid="demo-change-country"
                >
                  🌍 تغيير الدولة
                </Button>
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="text-xs bg-telegram-blue text-white hover:bg-telegram-dark"
                  data-testid="demo-main-menu"
                >
                  🔙 القائمة الرئيسية
                </Button>
              </div>
            </div>
          </div>

          {/* Code Received */}
          <div className="flex">
            <div className="bg-white rounded-lg p-3 max-w-md shadow-sm border-2 border-success">
              <p className="text-sm mb-2 text-success font-semibold">تم استلام الكود! ✅</p>
              <div className="mb-2">
                <p className="text-xs text-gray-600 mb-1">الرقم:</p>
                <div className="bg-gray-100 p-2 rounded font-mono text-center text-sm" data-testid="demo-final-number">
                  +20123456789
                </div>
              </div>
              <div>
                <p className="text-xs text-gray-600 mb-1">الكود:</p>
                <div className="bg-success bg-opacity-20 p-2 rounded font-mono text-center text-lg font-bold" data-testid="demo-verification-code">
                  123456
                </div>
              </div>
              <p className="text-xs text-gray-500 mt-2">تم خصم 0.50$ من رصيدك</p>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
