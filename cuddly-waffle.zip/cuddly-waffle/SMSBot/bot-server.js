
const express = require('express');
const path = require('path');
const { exec } = require('child_process');

const app = express();
const PORT = process.env.PORT || 3000;

// إعداد الملفات الثابتة
app.use(express.static('.'));
app.use(express.json());

// الصفحة الرئيسية
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// صفحة تسجيل الدخول
app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'login.html'));
});

// لوحة التحكم
app.get('/dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'dashboard.html'));
});

// API للبوت
app.get('/api/bot/status', (req, res) => {
    res.json({ status: 'active', bots: [] });
});

// تشغيل البوت
app.post('/api/bot/start', (req, res) => {
    const { token, adminId } = req.body;
    
    if (!token || !adminId) {
        return res.status(400).json({ error: 'التوكن ومعرف الأدمن مطلوبان' });
    }

    // تشغيل البوت في مجلد SMSBot
    exec(`cd SMSBot && BOT_TOKEN=${token} ADMIN_ID=${adminId} npm start`, (error, stdout, stderr) => {
        if (error) {
            console.error('خطأ في تشغيل البوت:', error);
            return res.status(500).json({ error: 'فشل في تشغيل البوت' });
        }
        
        res.json({ 
            success: true, 
            message: 'تم تشغيل البوت بنجاح',
            output: stdout
        });
    });
});

// بدء السيرفر
app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 السيرفر يعمل على المنفذ ${PORT}`);
    console.log(`🔗 الرابط: http://localhost:${PORT}`);
});
