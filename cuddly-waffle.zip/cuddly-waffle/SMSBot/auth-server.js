
const express = require('express');
const path = require('path');
const app = express();
const port = 5000;

// Store for verification codes (في التطبيق الحقيقي يجب استخدام قاعدة بيانات)
const verificationCodes = new Map();

app.use(express.json());
app.use(express.static('.'));

// إرسال كود التحقق
app.post('/api/auth/send-code', async (req, res) => {
    const { userInput } = req.body;
    
    if (!userInput) {
        return res.json({ success: false, message: 'يجب إدخال اليوزر نيم أو الآيدي' });
    }

    // توليد كود عشوائي
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    
    // حفظ الكود مؤقتاً (5 دقائق)
    verificationCodes.set(userInput, {
        code: code,
        expires: Date.now() + 5 * 60 * 1000
    });

    try {
        // هنا يتم إرسال الكود عبر البوت
        await sendCodeViaTelegram(userInput, code);
        
        res.json({ 
            success: true, 
            message: 'تم إرسال الكود بنجاح' 
        });
    } catch (error) {
        console.error('خطأ في إرسال الكود:', error);
        res.json({ 
            success: false, 
            message: 'فشل في إرسال الكود' 
        });
    }
});

// التحقق من الكود
app.post('/api/auth/verify-code', (req, res) => {
    const { userInput, code } = req.body;
    
    const storedData = verificationCodes.get(userInput);
    
    if (!storedData) {
        return res.json({ success: false, message: 'كود منتهي الصلاحية' });
    }
    
    if (Date.now() > storedData.expires) {
        verificationCodes.delete(userInput);
        return res.json({ success: false, message: 'كود منتهي الصلاحية' });
    }
    
    if (storedData.code !== code) {
        return res.json({ success: false, message: 'كود خاطئ' });
    }
    
    // حذف الكود بعد الاستخدام
    verificationCodes.delete(userInput);
    
    // توليد token (في التطبيق الحقيقي يجب استخدام JWT)
    const token = 'auth_' + Date.now() + '_' + Math.random().toString(36);
    
    res.json({ 
        success: true, 
        token: token,
        message: 'تم تسجيل الدخول بنجاح' 
    });
});

// دالة إرسال الكود عبر التيليجرام
async function sendCodeViaTelegram(userInput, code) {
    // هنا تتم محاولة البحث عن المستخدم وإرسال الكود
    console.log(`إرسال كود ${code} للمستخدم ${userInput}`);
    
    // محاكاة إرسال الكود (في التطبيق الحقيقي يتم الإرسال عبر Telegram Bot API)
    return new Promise((resolve) => {
        setTimeout(() => {
            console.log('تم إرسال الكود بنجاح');
            resolve(true);
        }, 1000);
    });
}

// الصفحات الثابتة
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'login.html'));
});

app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'login.html'));
});

app.get('/dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'dashboard.html'));
});

app.listen(port, '0.0.0.0', () => {
    console.log(`🚀 Server running at http://0.0.0.0:${port}`);
    console.log(`📱 Login page: http://0.0.0.0:${port}/login.html`);
    console.log(`📊 Dashboard: http://0.0.0.0:${port}/dashboard.html`);
});
