// بيانات الدول مع أرمز الاتصال
const countries = [
    { name: 'السعودية', code: 'SA', dialCode: '+966' },
    { name: 'الإمارات', code: 'AE', dialCode: '+971' },
    { name: 'مصر', code: 'EG', dialCode: '+20' },
    { name: 'الكويت', code: 'KW', dialCode: '+965' },
    { name: 'قطر', code: 'QA', dialCode: '+974' },
    { name: 'البحرين', code: 'BH', dialCode: '+973' },
    { name: 'عُمان', code: 'OM', dialCode: '+968' },
    { name: 'الأردن', code: 'JO', dialCode: '+962' },
    { name: 'لبنان', code: 'LB', dialCode: '+961' },
    { name: 'سوريا', code: 'SY', dialCode: '+963' },
    { name: 'العراق', code: 'IQ', dialCode: '+964' },
    { name: 'المغرب', code: 'MA', dialCode: '+212' },
    { name: 'الجزائر', code: 'DZ', dialCode: '+213' },
    { name: 'تونس', code: 'TN', dialCode: '+216' },
    { name: 'ليبيا', code: 'LY', dialCode: '+218' },
    { name: 'السودان', code: 'SD', dialCode: '+249' },
    { name: 'اليمن', code: 'YE', dialCode: '+967' },
    { name: 'فلسطين', code: 'PS', dialCode: '+970' },
    { name: 'تركيا', code: 'TR', dialCode: '+90' },
    { name: 'إيران', code: 'IR', dialCode: '+98' },
    { name: 'الولايات المتحدة', code: 'US', dialCode: '+1' },
    { name: 'كندا', code: 'CA', dialCode: '+1' },
    { name: 'بريطانيا', code: 'GB', dialCode: '+44' },
    { name: 'فرنسا', code: 'FR', dialCode: '+33' },
    { name: 'ألمانيا', code: 'DE', dialCode: '+49' },
    { name: 'إيطاليا', code: 'IT', dialCode: '+39' },
    { name: 'إسبانيا', code: 'ES', dialCode: '+34' },
    { name: 'روسيا', code: 'RU', dialCode: '+7' },
    { name: 'الصين', code: 'CN', dialCode: '+86' },
    { name: 'اليابان', code: 'JP', dialCode: '+81' },
    { name: 'كوريا الجنوبية', code: 'KR', dialCode: '+82' },
    { name: 'الهند', code: 'IN', dialCode: '+91' },
    { name: 'باكستان', code: 'PK', dialCode: '+92' },
    { name: 'بنغلاديش', code: 'BD', dialCode: '+880' },
    { name: 'إندونيسيا', code: 'ID', dialCode: '+62' },
    { name: 'ماليزيا', code: 'MY', dialCode: '+60' },
    { name: 'تايلاند', code: 'TH', dialCode: '+66' },
    { name: 'الفلبين', code: 'PH', dialCode: '+63' },
    { name: 'سنغافورة', code: 'SG', dialCode: '+65' },
    { name: 'أستراليا', code: 'AU', dialCode: '+61' },
    { name: 'نيوزيلندا', code: 'NZ', dialCode: '+64' },
    { name: 'البرازيل', code: 'BR', dialCode: '+55' },
    { name: 'الأرجنتين', code: 'AR', dialCode: '+54' },
    { name: 'المكسيك', code: 'MX', dialCode: '+52' },
    { name: 'جنوب أفريقيا', code: 'ZA', dialCode: '+27' },
    { name: 'نيجيريا', code: 'NG', dialCode: '+234' },
    { name: 'كينيا', code: 'KE', dialCode: '+254' },
    { name: 'إثيوبيا', code: 'ET', dialCode: '+251' },
    { name: 'غانا', code: 'GH', dialCode: '+233' }
];

// متغيرات عامة
let services = JSON.parse(localStorage.getItem('smsServices')) || [];
let phoneNumbers = JSON.parse(localStorage.getItem('phoneNumbers')) || {};
let selectedCountry = null;

// تهيئة الصفحة
document.addEventListener('DOMContentLoaded', function() {
    displayServices();
    displayCountries();
    setupEventListeners();
    // عرض البوتات الموجودة عند تحميل الصفحة
    fetch('/api/bot/list')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                data.bots.forEach(bot => addBotToList(bot.name, bot.token, bot.adminId));
            }
        })
        .catch(error => console.error('Error fetching bots:', error));
});

// إعداد مستمعي الأحداث
function setupEventListeners() {
    // تبديل الأقسام
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
        });
    });

    // نموذج إضافة خدمة
    document.getElementById('service-form').addEventListener('submit', function(e) {
        e.preventDefault();
        addService();
    });

    // البحث في الخدمات
    document.getElementById('search-services').addEventListener('input', function() {
        displayServices(this.value);
    });

    // البحث في الدول
    document.getElementById('search-countries').addEventListener('input', function() {
        displayCountries(this.value);
    });

    // تبديل طريقة إدخال الأرقام
    document.querySelectorAll('input[name="input-method"]').forEach(radio => {
        radio.addEventListener('change', function() {
            toggleInputMethod(this.value);
        });
    });

    // رفع الملف
    document.getElementById('numbers-file').addEventListener('change', function() {
        handleFileUpload(this.files[0]);
    });

    // نموذج إضافة بوت
    document.getElementById('bot-form').addEventListener('submit', function(e) {
        e.preventDefault();
        addBot();
    });
}

// عرض الأقسام
function showSection(sectionId) {
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(sectionId).classList.add('active');
}

// إضافة خدمة جديدة
function addService() {
    const name = document.getElementById('service-name').value;
    const description = document.getElementById('service-description').value;
    const price = parseFloat(document.getElementById('service-price').value);

    if (!name || !price) {
        showMessage('يرجى ملء جميع الحقول المطلوبة', 'error');
        return;
    }

    const service = {
        id: Date.now(),
        name: name,
        description: description,
        price: price,
        createdAt: new Date().toLocaleDateString('ar-SA')
    };

    services.push(service);
    localStorage.setItem('smsServices', JSON.stringify(services));

    // إعادة تعيين النموذج
    document.getElementById('service-form').reset();

    // عرض رسالة نجاح
    showMessage('تم إضافة الخدمة بنجاح', 'success');

    // تحديث عرض الخدمات
    displayServices();
}

// عرض الخدمات
function displayServices(searchTerm = '') {
    const servicesList = document.getElementById('services-list');
    let filteredServices = services;

    if (searchTerm) {
        filteredServices = services.filter(service => 
            service.name.includes(searchTerm) || 
            service.description.includes(searchTerm)
        );
    }

    if (filteredServices.length === 0) {
        servicesList.innerHTML = '<p style="text-align: center; color: #666;">لا توجد خدمات متاحة</p>';
        return;
    }

    servicesList.innerHTML = filteredServices.map(service => `
        <div class="service-card">
            <h3>${service.name}</h3>
            <p><strong>الوصف:</strong> ${service.description || 'لا يوجد وصف'}</p>
            <p><strong>السعر:</strong> $${service.price}</p>
            <p><strong>تاريخ الإضافة:</strong> ${service.createdAt}</p>
            <button onclick="deleteService(${service.id})" style="background: #dc3545; color: white; border: none; padding: 8px 15px; border-radius: 5px; cursor: pointer; margin-top: 10px;">حذف</button>
        </div>
    `).join('');
}

// حذف خدمة
function deleteService(serviceId) {
    if (confirm('هل أنت متأكد من حذف هذه الخدمة؟')) {
        services = services.filter(service => service.id !== serviceId);
        localStorage.setItem('smsServices', JSON.stringify(services));
        displayServices();
        showMessage('تم حذف الخدمة بنجاح', 'success');
    }
}

// عرض الدول
function displayCountries(searchTerm = '') {
    const countriesList = document.getElementById('countries-list');
    let filteredCountries = countries;

    if (searchTerm) {
        filteredCountries = countries.filter(country => 
            country.name.includes(searchTerm) || 
            country.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
            country.dialCode.includes(searchTerm)
        );
    }

    countriesList.innerHTML = filteredCountries.map(country => `
        <div class="country-card" onclick="selectCountry('${country.code}')">
            <h3>${country.name}</h3>
            <p><strong>الرمز:</strong> ${country.code}</p>
            <p><strong>رمز الاتصال:</strong> ${country.dialCode}</p>
        </div>
    `).join('');
}

// اختيار دولة
function selectCountry(countryCode) {
    selectedCountry = countries.find(country => country.code === countryCode);

    // تحديث عرض الدول
    document.querySelectorAll('.country-card').forEach(card => {
        card.classList.remove('selected');
    });
    event.target.closest('.country-card').classList.add('selected');

    // إظهار نموذج إضافة الأرقام
    document.getElementById('numbers-form').style.display = 'block';
    document.getElementById('selected-country').textContent = `${selectedCountry.name} (${selectedCountry.dialCode})`;
}

// تبديل طريقة إدخال الأرقام
function toggleInputMethod(method) {
    const textInput = document.getElementById('text-input');
    const fileInput = document.getElementById('file-input');

    if (method === 'text') {
        textInput.style.display = 'block';
        fileInput.style.display = 'none';
    } else {
        textInput.style.display = 'none';
        fileInput.style.display = 'block';
    }
}

// التعامل مع رفع الملف
function handleFileUpload(file) {
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function(e) {
        const content = e.target.result;
        document.getElementById('numbers-text').value = content;
    };
    reader.readAsText(file);
}

// إضافة الأرقام
function addNumbers() {
    if (!selectedCountry) {
        showMessage('يرجى اختيار دولة أولاً', 'error');
        return;
    }

    const numbersText = document.getElementById('numbers-text').value.trim();
    if (!numbersText) {
        showMessage('يرجى إدخال الأرقام', 'error');
        return;
    }

    const numbers = numbersText.split('\n')
        .map(num => num.trim())
        .filter(num => num.length > 0)
        .map(num => {
            // إزالة المسافات والرموز غير المرغوب فيها
            return num.replace(/\s+/g, '').replace(/[^\d+]/g, '');
        })
        .filter(num => num.length > 0);

    if (numbers.length === 0) {
        showMessage('لم يتم العثور على أرقام صحيحة', 'error');
        return;
    }

    // حفظ الأرقام
    if (!phoneNumbers[selectedCountry.code]) {
        phoneNumbers[selectedCountry.code] = [];
    }

    // إضافة الأرقام الجديدة (تجنب التكرار)
    const existingNumbers = new Set(phoneNumbers[selectedCountry.code]);
    const newNumbers = numbers.filter(num => !existingNumbers.has(num));

    phoneNumbers[selectedCountry.code].push(...newNumbers);
    localStorage.setItem('phoneNumbers', JSON.stringify(phoneNumbers));

    // إعادة تعيين النموذج
    document.getElementById('numbers-text').value = '';
    document.getElementById('numbers-file').value = '';

    showMessage(`تم إضافة ${newNumbers.length} رقم جديد لدولة ${selectedCountry.name}`, 'success');
}

// عرض رسالة
function showMessage(message, type) {
    const messageDiv = document.createElement('div');
    messageDiv.className = type === 'success' ? 'success-message' : 'error-message';
    messageDiv.textContent = message;

    // إضافة الرسالة أعلى الصفحة
    const container = document.querySelector('.container');
    container.insertBefore(messageDiv, container.firstChild);

    // إزالة الرسالة بعد 3 ثواني
    setTimeout(() => {
        messageDiv.remove();
    }, 3000);
}

// عرض إحصائيات الأرقام
function showNumbersStats() {
    const stats = Object.keys(phoneNumbers).map(countryCode => {
        const country = countries.find(c => c.code === countryCode);
        return {
            country: country ? country.name : countryCode,
            count: phoneNumbers[countryCode].length
        };
    });

    console.table(stats);
}

// إضافة بوت جديد
function addBot() {
    const name = document.getElementById('bot-name').value;
    const token = document.getElementById('bot-token').value;
    const adminId = document.getElementById('admin-id').value;

    if (!name || !token || !adminId) {
        showMessage('يرجى ملء جميع الحقول', 'error');
        return;
    }

    // إرسال البيانات للسيرفر
    fetch('/api/bot/start', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            name: name,
            token: token,
            adminId: adminId
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showMessage('تم إضافة وتشغيل البوت بنجاح!', 'success');
            addBotToList(name, token, adminId);

            // تنظيف الحقول
            document.getElementById('bot-name').value = '';
            document.getElementById('bot-token').value = '';
            document.getElementById('admin-id').value = '';

            // العودة إلى قسم بوتاتي
            showSection('mybots');
        } else {
            showMessage(data.error || 'فشل في إضافة البوت', 'error');
        }
    })
    .catch(error => {
        showMessage('خطأ في الاتصال بالسيرفر', 'error');
        console.error('Error:', error);
    });
}

// إضافة البوت إلى القائمة
function addBotToList(name, token, adminId) {
    const botsList = document.getElementById('my-bots-list');

    // إزالة رسالة "لا توجد بوتات"
    const emptyState = botsList.querySelector('.empty-state');
    if (emptyState) {
        emptyState.remove();
    }

    const botCard = document.createElement('div');
    botCard.className = 'bot-card';
    botCard.innerHTML = `
        <div class="bot-info">
            <h4>🤖 ${name}</h4>
            <p><strong>التوكن:</strong> ${token.substring(0, 20)}...</p>
            <p><strong>الأدمن:</strong> ${adminId}</p>
            <span class="bot-status active">نشط</span>
        </div>
        <div class="bot-actions">
            <button onclick="manageBotCommands('${name}')" class="btn-secondary">الأوامر</button>
            <button onclick="stopBot('${token}')" class="btn-danger">إيقاف</button>
        </div>
    `;

    botsList.appendChild(botCard);
    updateBotsStats();
}

// إدارة أوامر البوت
function manageBotCommands(botName) {
    const commandsInfo = `
🤖 أوامر البوت ${botName}:

👤 أوامر المستخدم العادي:
/start - القائمة الرئيسية وبدء الخدمة
/mybalance - عرض الرصيد الحالي والمعاملات
/profile - عرض الملف الشخصي
/help - قائمة الأوامر والمساعدة

🔰 أوامر الأدمن المتقدمة:
/admin - لوحة التحكم الرئيسية
/balance <user_id> <amount> - إضافة أو خصم رصيد
/broadcast <message> - إرسال رسالة جماعية
/direct <user_id> <message> - إرسال رسالة مباشرة
/addnumber <phone_number> - إضافة رقم يدوياً
/stats - عرض إحصائيات شاملة
/users - قائمة المستخدمين
/settings - عرض إعدادات البوت
/maintenance - تفعيل/إلغاء وضع الصيانة
/channels - إدارة قنوات الاشتراك
/help - قائمة أوامر الأدمن

💡 ملاحظة: عند كتابة /help في أي بوت وأنت أدمن، ستظهر لك قائمة الأوامر المتاحة.
    `;

    alert(commandsInfo);
}

// إيقاف البوت
function stopBot(token) {
    if (confirm('هل تريد إيقاف هذا البوت؟')) {
        fetch('/api/bot/stop', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ token: token })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showMessage('تم إيقاف البوت', 'success');
                // هنا يمكن تحديث واجهة المستخدم لإظهار أن البوت متوقف
            } else {
                showMessage(data.error || 'فشل إيقاف البوت', 'error');
            }
        })
        .catch(error => {
            showMessage('خطأ في الاتصال بالسيرفر', 'error');
            console.error('Error stopping bot:', error);
        });
    }
}

// تحديث إحصائيات البوتات
function updateBotsStats() {
    const activeBots = document.querySelectorAll('.bot-card').length;
    document.getElementById('active-bots-count').textContent = activeBots;

    // محاكاة عدد المستخدمين
    document.getElementById('total-bot-users').textContent = activeBots * 150;
}